/* 
 * File:   main.cpp
 * Author: Ryan Peraza
 * Created on June 23, 2016, 6:51 PM
 * Purpose:  Computer Science is Cool Stuff
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data
    
    //Output the processed Data
cout<<"*************************************************"<<endl;
cout<<"             C C C        S S S S         !!"<<endl;
cout<<"           C       C     S        S       !!"<<endl;
cout<<"          C             S                 !!"<<endl;
cout<<"         C               S                !!"<<endl;
cout<<"         C                S S S S         !!"<<endl;
cout<<"         C                        S       !!"<<endl;
cout<<"          C                        S      !!"<<endl;
cout<<"           C       C     S        S         "<<endl;
cout<<"             C C C         S S S S        OO"<<endl;
cout<<"*************************************************"<<endl;
    //Exit Stage Right!
    return 0;
}