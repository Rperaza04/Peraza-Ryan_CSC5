/* 
 * File:   main.cpp
 * Author: Ryan Peraza
 * Created on June 23, 2016, 4:35 PM
 * Purpose:  The Sum of 2 Numbers
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int value1=62;//First Integer
    int value2=99;//Second Integer
    float sum;//Sum of two Integers
    
    //Input Data
    
    //Process the Data
    sum=value1+value2;
    
    //Output the processed Data
    cout<<"Integer 1 = "<<value1<<endl;
    cout<<"Integer 2 = "<<value2<<endl;
    cout<<"Sum = "<<sum<<endl;
    //Exit Stage Right!
    return 0;
}