/* 
 * File:   main.cpp
 * Author: Ryan Peraza
 * Created on June 30, 2016, 6:51 PM
 * Purpose:  Roman Numeral Conversion
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short x;
    unsigned char n1000s,n100s,n10s,n1s;
    
    //Input Data
    cout<<"Input a four digit number to convert"<<endl;
    cout<<"to star power"<<endl;
    cin>>x;
    
    
    //Process the Data
    if(x<0000||x>9999)return 1;
    
    //Output the processed Data
    //Thousands Position
    n1000s=(x-x%1000)/1000;
    switch(n1000s){
        case 9:cout<<"9 *********\n";break;
        case 8:cout<<"8 ********\n";break;
        case 7:cout<<"7 *******\n";break;
        case 6:cout<<"6 ******\n";break;
        case 5:cout<<"5 *****\n";break;
        case 4:cout<<"4 ****\n";break;
        case 3:cout<<"3 ***\n";break;
        case 2:cout<<"2 **\n";break;
        case 1:cout<<"1 *\n";break;
        case 0:cout<<"0 \n";
    }
    //Hundreds Position
    x-=n1000s*1000;
    n100s=(x-x%100)/100;
    switch(n100s){
        case 9:cout<<"9 *********\n";break;
        case 8:cout<<"8 ********\n";break;
        case 7:cout<<"7 *******\n";break;
        case 6:cout<<"6 ******\n";break;
        case 5:cout<<"5 *****\n";break;
        case 4:cout<<"4 ****\n";break;
        case 3:cout<<"3 ***\n";break;
        case 2:cout<<"2 **\n";break;
        case 1:cout<<"1 *\n";break;
        case 0:cout<<"0 \n";
    }
    //Tens Position
    x-=n100s*100;
    n10s=(x-x%10)/10;
    switch(n10s){
        case 9:cout<<"9 *********\n";break;
        case 8:cout<<"8 ********\n";break;
        case 7:cout<<"7 *******\n";break;
        case 6:cout<<"6 ******\n";break;
        case 5:cout<<"5 *****\n";break;
        case 4:cout<<"4 ****\n";break;
        case 3:cout<<"3 ***\n";break;
        case 2:cout<<"2 **\n";break;
        case 1:cout<<"1 *\n";break;
        case 0:cout<<"0 \n";
    }
    //Ones Position
    x-=n10s*10;
    n1s=(x-x%1)/1;
    switch(n1s){
        case 9:cout<<"9 *********\n";break;
        case 8:cout<<"8 ********\n";break;
        case 7:cout<<"7 *******\n";break;
        case 6:cout<<"6 ******\n";break;
        case 5:cout<<"5 *****\n";break;
        case 4:cout<<"4 ****\n";break;
        case 3:cout<<"3 ***\n";break;
        case 2:cout<<"2 **\n";break;
        case 1:cout<<"1 *\n";break;
        case 0:cout<<"0 \n";break;
    }
    
    //Exit Stage Right!
    return 0;
}
